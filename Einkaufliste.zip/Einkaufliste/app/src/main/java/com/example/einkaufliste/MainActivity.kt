package com.example.einkaufliste

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.einkaufliste.ui.theme.EinkauflisteTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EinkauflisteTheme { // Dein App-Theme
                ShoppingScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen() {
    // Zustand für die Liste der Artikel (Observable)
    val items = remember { mutableStateListOf<String>() }
    // Zustand für den Text im Eingabefeld
    var textState by remember { mutableStateOf("") }

    Scaffold( // Grundlegendes Material Design Layout Gerüst
        topBar = {
            TopAppBar(title = { Text("Einkaufsliste") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues) // Wichtig für korrekten Abstand unter der TopAppBar
                .padding(16.dp) // Zusätzliches Padding für den Inhalt
                .fillMaxSize()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = textState,
                    onValueChange = { textState = it },
                    label = { Text("Artikel eingeben") },
                    modifier = Modifier.weight(1f) // Nimmt den meisten Platz ein
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = {
                    if (textState.isNotEmpty()) {
                        items.add(textState)
                        textState = "" // Eingabefeld leeren
                    }
                }) {
                    Text("Add")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (items.isEmpty()) {
                Text(
                    text = "Noch keine Artikel hinzugefügt.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            } else {
                LazyColumn {
                    itemsIndexed(items) { index, item -> // itemsIndexed für Zugriff auf den Index
                        Text(
                            text = item,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    items.removeAt(index) // Artikel entfernen
                                }
                                .padding(vertical = 8.dp)
                        )
                        Divider() // Trennlinie
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    EinkauflisteTheme {
        ShoppingScreen()
    }
}